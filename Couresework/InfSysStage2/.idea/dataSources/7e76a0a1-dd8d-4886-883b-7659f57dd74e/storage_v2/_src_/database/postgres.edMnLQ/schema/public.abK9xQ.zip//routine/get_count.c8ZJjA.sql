create function get_count(p_expedition_id integer) returns integer
    language plpgsql
as
$$
    DECLARE
        participant_count INT;
    BEGIN
       SELECT COUNT(*)
        INTO participant_count
        FROM Request
        WHERE expedition_id = p_expedition_id AND status = 'принят';
       RETURN participant_count;
    END;
$$;

alter function get_count(integer) owner to hokure;

