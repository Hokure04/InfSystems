create function unique_phone() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS(
        SELECT 1
        FROM User_info
        WHERE phone_number = new.phone_number AND user_id <> new.user_id
    ) THEN
        RAISE EXCEPTION 'Номер телефона должен быть уникальным';
    end if;
    IF NEW.phone_number !~ '^[0-9]+$' THEN
        RAISE EXCEPTION 'Номер телефона не должен содержать ничего кроме цифр';
    end if;

    RETURN NEW;
END;
$$;

alter function unique_phone() owner to hokure;

