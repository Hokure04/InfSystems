create function get_route_hazards(p_route_id integer)
    returns TABLE(hazard_description text, risk_level integer)
    language plpgsql
as
$$
    BEGIN
       RETURN QUERY
        SELECT h.description, h.risk_level
        FROM Hazard h
        JOIN Location L on h.location_id = L.location_id
        WHERE l.route_id = p_route_id;
    END;
$$;

alter function get_route_hazards(integer) owner to hokure;

